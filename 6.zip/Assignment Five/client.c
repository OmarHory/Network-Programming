#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#include <dirent.h>
#define MAXSIZE 4096
#define FILESIZE 100000
char listFile[MAXSIZE]="";
void ls(int socketofConnectedClient);
void WriteRequest(int sfd, char choice[FILESIZE+4000], char req[FILESIZE], char cliantName[MAXSIZE]);
  int x = -1;

int main(int argc, char* argv[])
{

  if(argc !=4)
  {
    printf("Not enough arguments\n");
    return 1;
  }


  char filename[MAXSIZE]="";
  char filenameB[MAXSIZE]="";

  char filenamee[MAXSIZE]="";
  char filenameC[MAXSIZE]="";

  char empty[10]="000$";

  char name[MAXSIZE];
  strcpy(name,argv[3]);
  strcat(name,"$");


  int sockfd = socket(AF_INET,SOCK_STREAM,0);
  if(sockfd < 0)
  {
    perror("Couldn't create a socket");
    return 1;
  }
  struct sockaddr_in servaddr;
  memset(&servaddr,0,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(atoi(argv[2]));
   if( ( inet_pton(AF_INET,argv[1], &servaddr.sin_addr) ) ==0 )
   {
     perror("Invalid IP ADDRESS");
     return 1;
   }

 if( ( connect(sockfd, (struct sockaddr * ) &servaddr, sizeof(servaddr)) ) < 0)
 {
   perror("Couldn't connect to server\n");
   return 1;
 }
  else
  {

///////////////////////////////////

    while(x!=4)
    {

    printf("You're connected to the server:\nChoose one of the following tasks:\n1.List Files\n2.Download a file(Current Directory)\n3.upload a file\n4.Exit\n");

    scanf("%d",&x);



    if(x > 4)
    {
      perror("Wrong Choice\n");
      continue;
    }

    if(x==1)
    {
      char recvline[MAXSIZE]="";
      int n;
      char one[MAXSIZE]="one$";

        WriteRequest(sockfd,one,empty,name);
        read(sockfd,recvline,MAXSIZE);
        puts(recvline);
          sleep(1);

    }



  else if(x==2) //Downloading files
    {

        printf("Write the name of the file you want to download: ");
          scanf("%s",&filename);
          strcpy(filenameB,filename);

          strcat(filename,"$");

      int n;
      char recvline1[FILESIZE];
      char two[MAXSIZE]="two$";
      WriteRequest(sockfd,two,filename,name);


          if(n<0)
          {perror("Couldn't read.. Exiting..\n");
          exit(0);}
          sleep(1);
          memset(&recvline1, 0, sizeof(recvline1));

          while((n=read(sockfd,recvline1,FILESIZE))>0)
          {

            break;

          }

              if(strstr(recvline1,"Er#ror201")!=NULL)
              {
                printf("\nERROR: File is not found on the server\n");
              }

              else{
                  FILE *file=fopen(filenameB,"w");
               fprintf(file,recvline1);
              fclose(file);
              printf("-The file has been downloaded successfully.\n");

                  }

            printf("\n\n");
            memset(&recvline1, 0, sizeof(recvline1));


    }


  else if(x==3) //Uploading a file
    {
      printf("\n-------------------------\n");
      printf("Choose a text file to upload: \n\n");
      ls(sockfd);
      printf("-------------------------");
      printf("\n");
      printf("Give the name of the text file you want to upload: ");
      scanf("%s",&filenamee);
      strcpy(filenameC,filenamee);
      strcat(filenamee,"$");

      int n;
      char three[MAXSIZE]="three$";
      char fileContent[FILESIZE];

      WriteRequest(sockfd,three,filenamee,name);

      FILE *file1=fopen(filenameC,"r+");
      if(file1!=NULL)
      {


        while(fgets(fileContent,FILESIZE,file1)!=NULL)
        write(sockfd,fileContent,strlen(fileContent));
        printf("-Uploading...\nSuccess\n");

        memset(&fileContent, 0, sizeof(fileContent));
      }
            fclose(file1);

    }

    else if(x==4)
    {
      write(sockfd, "DONE", MAXSIZE);
      printf("Done\n");
    return 1;
  }


    }

    close(sockfd);
    return 0;
}
}

void WriteRequest(int sfd, char choice[FILESIZE+4000], char req[FILESIZE], char cliantName[MAXSIZE])
{
strcat(choice,cliantName);
strcat(choice,req);
write(sfd,choice,strlen(choice));

}

void ls(int socketofConnectedClient)
{

  DIR *dp;
  struct dirent *ep = malloc(sizeof(double) * 8);

      dp = opendir ("./");
      if (dp != NULL)
        {
          while (ep = readdir (dp))
          {
          strcat(listFile,"  ");
          strcat(listFile,ep->d_name);
          puts(ep->d_name);
          }

          memset(&listFile,0,sizeof(listFile));


        }
      else
        perror ("Couldn't open the directory");


        memset(&listFile,0,sizeof(listFile));


}
