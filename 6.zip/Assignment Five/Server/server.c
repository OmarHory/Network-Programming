#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#include <limits.h>
#include <signal.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

#define FILESIZE 100000
#define MAXSIZE 4096
#define LISTENQ 1024
char listFile[MAXSIZE];
char nameClient[MAXSIZE];
char requestG[MAXSIZE];
void sig_child (int signo);
void ls(int socketofConnectedClient, int a);
void parse(int sfd, char c[MAXSIZE],int o);



int main(int argc, char* argv[])
{

  if(argc!=2)
  {
    printf("Not enough arguments\n");
    return 1;
  }

  int listenfd=socket(AF_INET,SOCK_STREAM,0);
  if(listenfd<0)
  {perror("Couldn't create listen socket\n");
  return 1;}

  struct sockaddr_in servaddr;
  memset(&servaddr,0,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(atoi(argv[1]));
  struct sockaddr_in cliaddr;
  memset(&cliaddr,0,sizeof(cliaddr));
  cliaddr.sin_family=AF_INET;
  cliaddr.sin_port=htons(atoi(argv[1]));
  if( ( inet_pton(AF_INET,"127.0.0.1", &servaddr.sin_addr) ) ==0 )
  {
    perror("Invalid IP ADDRESS");
    return 1;}

  if ( (bind(listenfd,(struct sockaddr * ) &servaddr, sizeof(servaddr)) )<0 )
  {perror("Couldn't bind\n");
return 1;}
if((listen(listenfd,LISTENQ))<0)
{
  perror("Couldn't listen\n");
  return 1;
}

  int connfd;
  socklen_t len;
  int pid;
    len =sizeof(cliaddr);

signal(SIGCHLD, sig_child);

  for( ; ; )
  {

    connfd=accept(listenfd, (struct sockaddr * ) &cliaddr, &len);


    if(connfd<0)
    {perror("Couldn't accept client");
    continue;
    }
    ls(connfd,0);
    if( (pid = fork()) == 0 ) { // Child

      int n;
      close(listenfd);
      char receivedReq[FILESIZE];

      while(   (n= read(connfd, receivedReq, FILESIZE)) >0){

        if(n<0)
        {perror("Can't read request, try again later\n");
        exit(0);}

          if( strstr(receivedReq,"one$")!=NULL )
          {
          parse(connfd,receivedReq,0);
}
            else if( strstr(receivedReq,"two$")!=NULL )
            {
                char recvFileContent[FILESIZE];
                parse(connfd,receivedReq,1);

                if( strstr(listFile,requestG)!=NULL )
                {
                FILE *file=fopen(requestG,"r");
                while(fgets(recvFileContent,FILESIZE,file)!=NULL)
                {

                write(connfd, recvFileContent,strlen(recvFileContent));
              }


                printf("-Sending a file to client...\nSuccess\n");
                fclose(file);

                }
                  else
                  write(connfd, "Er#ror201 file not found\n",MAXSIZE);
                          memset(&recvFileContent,0,sizeof(recvFileContent));
                          memset(&listFile,0,sizeof(listFile));
          }
              else if( strstr(receivedReq,"three$")!=NULL )
              {
                int n=0;
                char recvFileContent1[FILESIZE];
                parse(connfd,receivedReq,1);

                char dirName[100+1];
                struct stat st = {0};
                snprintf(dirName, 500 + 1,nameClient);


                        char libPath[500+1];
                        strcat(dirName,"/");
                        strcat(dirName,requestG);
                        snprintf(libPath, 500 + 1, dirName);
                        memset(&receivedReq,0,sizeof(receivedReq));
                        sleep(1);
                      while((n=read(connfd,recvFileContent1, FILESIZE))>0)
                      {
                        recvFileContent1[n]=0;
                        break;
                      }
                      if(n>0)
                      {
                        FILE *fLib = fopen(libPath , "w+");
                        fprintf(fLib,recvFileContent1);
                        fclose(fLib);
                        printf("-The server has received a file to %s Directory\n",nameClient);
                        memset(&recvFileContent1,0,sizeof(recvFileContent1));
                        memset(&listFile,0,sizeof(listFile));
                      }
                      else
                      {
                        printf("Can't read from client... Exiting\n");
                        exit(0);
                      }

              }
                else if( strstr(receivedReq,"DONE")!=NULL )
                {
                  printf("A client has been disconnected\n");
                  close(connfd); // done with this client
                  exit(0);
                  // child terminates

                }

                    memset(&receivedReq,0,sizeof(receivedReq));
        }

} //IF PID
    else
      // Parent
      close(connfd); // close connected socket

  }

  return 0;
}
void ls(int socketofConnectedClient, int a)
{

  DIR *dp;
  struct dirent *ep = malloc(sizeof(double) * 8);

      dp = opendir ("./");
      if (dp != NULL)
        {
          while (ep = readdir (dp))
          {
          strcat(listFile,"\n");
          strcat(listFile,ep->d_name);
          }


        }
      else
        perror ("Couldn't open the directory");

        if(a==1)
        write(socketofConnectedClient, listFile, MAXSIZE);
        if(a==0 || a==1)
        memset(&listFile,0,sizeof(listFile));


}

void parse(int sfd, char c[MAXSIZE],int o)
{

  int i=0;
  char * pch;
  char *cpypch[MAXSIZE];

  pch = strtok(c,"$");

    while (pch != NULL)
      {
        cpypch[i]=pch;
        i++;
        pch = strtok (NULL, "$");
    }

    memcpy(nameClient,cpypch[1],sizeof(cpypch[1]));
    if(o==1)
    memcpy(requestG,cpypch[2],sizeof(cpypch[2]));

    if(o==0)
    ls(sfd,1);

    if(o==1)
    ls(sfd,2);
  }

void sig_child (int signo) {
pid_t pid;
int stat;
while((pid = waitpid(-1, &stat, WNOHANG)) > 0)
printf("Child %d terminated.\n", pid);
}
