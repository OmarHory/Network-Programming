#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#include <limits.h>
#include <signal.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/types.h>
#define MAX_BUFF 2048
#define MAX_MSG  20480
#define MOD 1024
#define SIGGO SIGCONT
int handle(char* req,char* res);
int getAVG(char* req,char* res);
int getMIN(char* req,char* res);
int min(int a,int b);
void sigchild(int sig);
void sigint(int sig);
void sig_wait(int sig);
void sigseg(int sig);
int x=0,glofd=0;
int qFront=0,qBack=0;
int q[MOD];
int ex=1;
int conCount=0,qLen=0;
int w;
int main(int argc, char *argv[]){
  time_t tm;
  time(&tm);
  signal(SIGCHLD,sigchild);
  signal(SIGINT,sigint);
  signal(SIGGO,sig_wait);
  signal(SIGSEGV,sigseg);
  char *res=malloc(MAX_BUFF);;
  int port = atoi(argv[1]);
  char req[MAX_BUFF+1];
  if(port<=0 || port > (1<<16)-1 ){ //Check if port number is valid
     puts("Invalid port.");
   return 1;
  }
  struct sockaddr_in myaddr,cliaddr;
  int myfd=socket(AF_INET,SOCK_STREAM,0),clifd;
  if(myfd<0){
    perror("Cannot create socket."); //Catching socket errors
    return 1;
  }
  glofd=myfd;
  memset(&myaddr,0,sizeof myaddr); //clearing address struct
  myaddr.sin_family = AF_INET; //IPv4
  myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  myaddr.sin_port = htons(port);

  int ret=bind(myfd,(struct sockaddr*)&myaddr,sizeof (myaddr));
  if(ret<0){
    perror("Cannot bind socket.");
    return 1;
  }
  FILE * lg=fopen("log.txt","w");
  ret=listen(myfd,1);
  if(ret<0){
    perror("Cannot listen.");
  }
  memset(q,-1,sizeof q);

  while(ex){
    socklen_t len = sizeof(cliaddr);
    clifd=accept(myfd,(struct sockaddr*)&cliaddr,&len);
    conCount++;
    x=w=0;

    if(conCount>4){
      w=1;
      conCount--;
      if(qLen>=MOD){
        close(clifd);
        continue;
      }
      qLen++;
      q[qBack]=fork();
    }
    else x=fork();
    if(q[qBack]==0||q[qBack]==-1&&x==0){
      int myc=qBack;
      close(myfd);
      int n;
      int line=0;
      char buff[20];
      while(w){
        sleep(1);
      }
      while((n=read(clifd,req,MAX_BUFF))>0){
        req[n]=0;
        line++;
        int retVal = handle(req,res);
        if(retVal){
          char err[64];
          sprintf(err,"Unsupported Operation on Line #%d\n",line);
          write(clifd,err,strlen(err));
          fprintf(lg,"TIME: %sIP: %s\nRequest: %sState: Unsuccessful\n%0*d\n",ctime(&tm),inet_ntop(AF_INET,&cliaddr.sin_addr,buff,20),req,37,0);
        }
        else{
          write(clifd,res,strlen(res));
          //printf("TIME: %sIP: %s\nRequest: %s\nState: Successful\n%0*d\n",ctime(&tm),inet_ntop(AF_INET,&cliaddr.sin_addr,buff,20),req,37,0);
        fprintf(lg,"TIME: %sIP: %s\nRequest: %s\nState: Successful\n%0*d\n",ctime(&tm),inet_ntop(AF_INET,&cliaddr.sin_addr,buff,20),req,37,0);
        perror("");
        }
      }
    fclose(lg);
    exit(0);
}
  if(q[qBack]!=-1)
  qBack=(qBack+1)%MOD;
  close(clifd);
  fclose(lg);
}

}

int handle(char* req,char* res){
  char op[10];
  sscanf(req,"%s",op);
  if(!(strcmp(op,"AVG"))){
    if(getAVG(req,res)){
      return 1;
    }
    return 0;
  }
  else if(!(strcmp(op,"MIN"))){
    if(getMIN(req,res)){
    return 1;
    }
    return 0;
  }
  else {
    res=NULL;
    return -1;
  }
}
int getAVG(char* reqq,char* res){
  int TOK[101];
  char req[MAX_BUFF+1];
  strcpy(req,reqq);
  char* t=strtok(req," ");
  int i=0;
  t=strtok(NULL," ");
  while(t!=NULL){
      TOK[i++]=(int)strtol(t,NULL,10);
      t=strtok(NULL," ");
  }
  if(i<1){
    res=NULL;
    return 1;
  }
  sprintf(res,"AVERAGE(");
  float avg=0;
  for(int j=0;j<i;j++){
    char x[27],y[27];
    avg+=TOK[j];
    if(j<i-1){
      sprintf(x,"%d, ",TOK[j]);
    }else{
      sprintf(x,"%d) = ",TOK[j]);
    }
    strcat(res,x);
    if(j==i-1){
      sprintf(y,"%.4f\n",avg/i);
      strcat(res,y);
    }
    }
    res[strlen(res)]=0;
 return 0;
}
int getMIN(char* reqq,char* res){
  int TOK[101];
  char req[MAX_BUFF+1];
  strcpy(req,reqq);
  char* t=strtok(req," ");
  int i=0;
  t=strtok(NULL," ");
  while(t!=NULL){
      TOK[i++]=(int)strtol(t,NULL,10);
      t=strtok(NULL," ");
  }
  if(i<1){
    res=NULL;
    return 1;
  }
  sprintf(res,"MIN(");
  int mn=INT_MAX;
  for(int j=0;j<i;j++){
    char x[27],y[27];
    mn=min(mn,TOK[j]);
    if(j<i-1){
      sprintf(x,"%d, ",TOK[j]);
    }else{
      sprintf(x,"%d) = ",TOK[j]);
    }
    strcat(res,x);
    if(j==i-1){
      sprintf(y,"%d\n",mn);
      strcat(res,y);
    }
  }
    res[strlen(res)]=0;
  return 0;
}
int min(int a,int b){
  if(a>b)return b;
  return a;
}
void sigchild(int sig){
  while(waitpid(-1,NULL,WNOHANG)>0){
    conCount--;
    if(qLen>0){
      kill(q[qFront++],SIGGO);
      int qq=q[qFront-1];
      conCount++;
      qLen--;
      q[qFront-1]=-1;
      qFront%=MOD;
    }


 }
  }
void sigint(int sig){
 close(glofd);
 exit(0);
}
void sig_wait(int sig){
  w=0;
}
void sigseg(int sig){
  exit(0);
}
