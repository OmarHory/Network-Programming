#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#define MAX_SIZE 2048
#define MAX_MSG  20480
int main(int argc, char *argv[]){
  char * IP = argv[1];
  int port = atoi(argv[2]);
  FILE* file = fopen(argv[4],"r");
  int wait = atoi(argv[3]);
  int sockfd=socket(AF_INET,SOCK_STREAM,0);
  if(sockfd<0){
      perror("Cannot create socket."); //Catching socket errors
      return 1;
    }

  struct sockaddr_in servaddr;

  struct in_addr nIP;
  if(inet_aton(IP,&nIP)==0){ //Check if IP is valid; if valid, store into in_addr, else exit
    puts("Invalid IP address.");
    return 1;
  }
  if(port<=0 || port > (1<<16)-1 ){ //Check if port numbers are valid
     puts("Invalid port.");
   return 1;
 }

  memset(&servaddr,0,sizeof servaddr); //clearing address struct
  servaddr.sin_family = AF_INET; //IPv4
  servaddr.sin_addr = nIP;
  servaddr.sin_port = htons(port);

  if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof servaddr)<0){
    puts("Connection Failed.");
    return 1;
  }
  char op[MAX_SIZE+1];
  char res[MAX_SIZE+1];
  int n;
  //n=read(sockfd,res,MAX_SIZE);
  //if(n<0)return 1;
  //puts(res);
  while(0){
    sleep(5);
    puts("retry");
    close(sockfd);
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0){
        perror("Cannot create socket."); //Catching socket errors
        return 1;
      }
    if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof servaddr)<0){
      puts("Connection Failed.");
      return 1;
    }
    n=read(sockfd,res,MAX_SIZE);
    if(n<0)return 1;
  }
  puts("Connected");
  while(fgets(op,MAX_SIZE,stdin)!=NULL){
    op[strlen(op)-1]=' ';
    char req[MAX_SIZE+1];
    sprintf(req,"%s",op);
    write(sockfd,req,strlen(req));
    n=read(sockfd,res,MAX_SIZE);
    res[n-1]=0;
    printf(res);

    puts("");

    usleep(wait);
  }
 close(sockfd);

}
void f(int sig){}
