/*
Network Programming Assignment 1:
Group# 13
Name: Omar Fadel Naman
Name2: Omar Radwan ALHory

*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_SIZE 1024 

struct ISBN{
  long int value;
};

struct Author{
  char authorName[MAX_SIZE];
};

struct BookInfo{
    char* bookTitle;
    struct Author bookAuthor;
    struct ISBN bookNumber;
};
//Function Prototypes
void fillin (FILE *, struct BookInfo *);

void printInfo (const struct BookInfo *);

int IsSameAuthor (const struct BookInfo *, const struct BookInfo *);

int main() {
    FILE* inp;
    inp=fopen("in.txt","r"); // Opening File

    if(inp == NULL ) //Catching FileNotFound Exception
    {
      perror("File not Found");
      return 1;
}
    struct BookInfo bk1,bk2;
    //Filling and Printing bk1
    fillin(inp, &bk1);
    printInfo(&bk1);
    //Filling And Printing bk2
    fillin(inp, &bk2);
	printInfo(&bk2);

    printf("is Equal? : %s\n",(IsSameAuthor(&bk1,&bk2))?"NO":"YES"); //IsSameAuthor?
    fclose(inp);// Closing File
    return 0;

}


void fillin (FILE * file, struct BookInfo * bk){
    char inp[MAX_SIZE];
    long int inpL;
    //memset(bk,0,sizeof(bk)); 
    //read bookTitle
          fgets(inp,MAX_SIZE,file);
          bk->bookTitle=malloc((strlen(inp)+1)*sizeof(char));
          strcpy(bk->bookTitle,inp);
    //read bookAuthor
          fgets(inp,MAX_SIZE,file);
          strcpy(bk->bookAuthor.authorName,inp);
    //read bookNumber
          fscanf(file,"%li", &inpL);
          bk->bookNumber.value=inpL;
    //skip \n
          fgets(inp,2,file);
	

}

void printInfo (const struct BookInfo * bk){
  printf("Title: %sISBN: %li\nBy: %s",bk->bookTitle,bk->bookNumber.value,bk->bookAuthor.authorName);
}

int IsSameAuthor (const struct BookInfo * bk1, const struct BookInfo * bk2){
  return (strcmp(bk1->bookAuthor.authorName,bk2->bookAuthor.authorName));
}

