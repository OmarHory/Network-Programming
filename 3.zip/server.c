#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#include <limits.h>
#include <signal.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/types.h>
#define MAX_BUFF 2048   //Size of Message
#define MOD 1024        //Size of Queue
#define MAX_CONN 4
/*Functions Prototypes*/
int handle(char* req,char* res);
int getAVG(char* req,char* res);
int getMIN(char* req,char* res);
int min(int a,int b);

/*Signal Handlers*/
void sigchild(int sig);
void sigint(int sig);

/*Global Variables*/
int x=0,w=0,glofd=0;    //Control Variables
int qFront=0,qBack=0;   //Queue Front Back
int q[MOD];             //Wait Queue
int conCount=0,qLen=0;  //Connected Count, Queue Size



int main(int argc, char *argv[]){
  /*Time Settings*/
  time_t tm;
  time(&tm);
  /*Assign Signal handlers to Signals*/
  signal(SIGCHLD,sigchild);
  signal(SIGINT,sigint);

  char *res=malloc(MAX_BUFF);;
  int port = atoi(argv[1]);
  char req[MAX_BUFF+1];
  /*Check if port number is valid*/
  if(port<=0 || port > (1<<16)-1 ){
     puts("Invalid port.");
   return 1;
  }

  struct sockaddr_in myaddr,cliaddr;
  /*Creating Server Socket*/
  int myfd=socket(AF_INET,SOCK_STREAM,0),clifd;
  if(myfd<0){
    perror("Cannot create socket."); //Catching socket errors
    return 1;
  }

  glofd=myfd; //To handle interrupts

  /*Setting Up Server Address struct*/
  memset(&myaddr,0,sizeof myaddr);
  myaddr.sin_family = AF_INET;
  myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  myaddr.sin_port = htons(port);
  /*Binding Socket to Address struct*/
  int ret=bind(myfd,(struct sockaddr*)&myaddr,sizeof (myaddr));
  if(ret<0){
    perror("Cannot bind socket.");
    return 1;
  }
  /*Opening LOG file*/
  FILE * lg=fopen("log.txt","w");
  /*Listening*/
  ret=listen(myfd,MOD);
  if(ret<0){
    perror("Cannot listen.");
  }

  memset(q,-1,sizeof q);    //Clearing Queue

  while(1){
    socklen_t len = sizeof(cliaddr);
    clifd=accept(myfd,(struct sockaddr*)&cliaddr,&len);
    conCount++;
    x=w=0;
    /*if Already 4 clients are connected*/
    if(conCount>MAX_CONN){
      w=1;
      conCount--;
      /*If client has no room in Queue (Prevents huge memory allocation)*/
      if(qLen>=MOD){
        close(clifd);
        continue;
      }
      qLen++;
      q[qBack]=fork(); //PUSH client ID into Queue
    }
    else x=fork(); //SAVE client ID

    /*If Child*/
    if(q[qBack]==0||q[qBack]==-1&&x==0){
      close(myfd);
      int n;
      int line=0;
      char buff[20];
      if(w){kill(getpid(),SIGSTOP);}    //STOP if placed in Queue
      /*Recieve Requests*/
      while((n=read(clifd,req,MAX_BUFF))>0){
        req[n]=0;
        line++;
        /*Handle Request*/
        int retVal = handle(req,res);
        if(retVal){
          char err[64];
          sprintf(err,"Unsupported Operation on Line #%d\n",line);
          write(clifd,err,strlen(err));
          fprintf(lg,"TIME: %sIP: %s\nRequest: %sState: Unsuccessful\n%0*d\n",ctime(&tm),inet_ntop(AF_INET,&cliaddr.sin_addr,buff,20),req,37,0);
        }
        else{
          write(clifd,res,strlen(res));
          fprintf(lg,"TIME: %sIP: %s\nRequest: %sState: Successful\n%0*d\n",ctime(&tm),inet_ntop(AF_INET,&cliaddr.sin_addr,buff,20),req,37,0);
        }
      }
      fclose(lg);
      exit(0);
    }
    /*Parent Code (Move Queue Back)*/
    if(q[qBack]!=-1)
    qBack=(qBack+1)%MOD;
    close(clifd);
  }
  /*Terminate Server (added for clarity)*/
  close(myfd);
  fclose(lg);
}
int handle(char* req,char* res){
  /*Define Operation*/
  char op[10];
  sscanf(req,"%s",op);
  if(!(strcmp(op,"AVG"))){
    if(getAVG(req,res)){
      return 1;
    }
    return 0;
  }
  else if(!(strcmp(op,"MIN"))){
    if(getMIN(req,res)){
      return 1;
    }
    return 0;
  }
  else {
    res=NULL;
    return -1;
  }
}
int getAVG(char* reqq,char* res){
  /*Extract Operands and calculate AVG*/
  int TOK[101];
  char req[MAX_BUFF+1];
  strcpy(req,reqq);
  char* t=strtok(req," ");
  int i=0;
  t=strtok(NULL," ");
  while(t!=NULL){
    char *back;
    TOK[i++]=(int)strtol(t,&back,10);
    if(t==back) {res=NULL;return 1;}
    t=strtok(NULL," ");
  }
  /*if no operands*/
  if(i<1){
    res=NULL;
    return 1;
  }
  sprintf(res,"AVERAGE(");
  float avg=0;
  for(int j=0;j<i;j++){
    char x[27],y[27];
    avg+=TOK[j];
    if(j<i-1){
      sprintf(x,"%d, ",TOK[j]);
    }else{
      sprintf(x,"%d) = ",TOK[j]);
    }
    strcat(res,x);
    if(j==i-1){
      sprintf(y,"%.4f\n",avg/i);
      strcat(res,y);
    }
    }
    res[strlen(res)]=0;
 return 0;
}
int getMIN(char* reqq,char* res){
  /*Extract Operands and calculate MIN*/
  int TOK[101];
  char req[MAX_BUFF+1];
  strcpy(req,reqq);
  char* t=strtok(req," ");
  int i=0;
  t=strtok(NULL," ");
  while(t!=NULL){
    char* back;
    TOK[i++]=(int)strtol(t,&back,10);
    if(t==back){res=NULL;return 1;}
    t=strtok(NULL," ");
  }
  /*if no operands*/
  if(i<1){
    res=NULL;
    return 1;
  }
  sprintf(res,"MIN(");
  int mn=INT_MAX;
  for(int j=0;j<i;j++){
    char x[27],y[27];
    mn=min(mn,TOK[j]);
    if(j<i-1){
      sprintf(x,"%d, ",TOK[j]);
    }else{
      sprintf(x,"%d) = ",TOK[j]);
    }
    strcat(res,x);
    if(j==i-1){
      sprintf(y,"%d\n",mn);
      strcat(res,y);
    }
  }
    res[strlen(res)]=0;
  return 0;
}
int min(int a,int b){
  /*Simple Min function*/
  if(a>b)return b;
  return a;
}
void sigchild(int sig){

  while(waitpid(-1,NULL,WNOHANG)>0){
    conCount--;
    /*if Queue isn't empty*/
    if(qLen>0){
      kill(q[qFront++],SIGCONT); //POP Queue
      conCount++;
      qLen--;
      q[qFront-1]=-1; //Move Queue front
      qFront%=MOD;
    }
 }
}
void sigint(int sig){
  /*Handle interrupt*/
 close(glofd);
 exit(0);
}
