#include	<sys/socket.h>
#include	<netinet/in.h>
#include  <arpa/inet.h>
#include 	<netinet/in.h>
#include 	<stdio.h>
#include	<string.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <errno.h>
#define MAX_SIZE 2048   //Size of Message

int main(int argc, char *argv[]){
  /*Get command line arguments*/
  char * IP = argv[1];
  int port = atoi(argv[2]);
  FILE* file = fopen(argv[4],"r");
  int wait = atoi(argv[3]);
  /*Creating Server Socket*/
  int sockfd=socket(AF_INET,SOCK_STREAM,0);
  if(sockfd<0){
      perror("Cannot create socket."); //Catching socket errors
      return 1;
    }

  struct sockaddr_in servaddr;

  struct in_addr nIP;
  /*Check if IP is valid; if valid, store into in_addr, else exit*/
  if(inet_aton(IP,&nIP)==0){
    puts("Invalid IP address.");
    return 1;
  }
  /*Check if port number is valid*/
  if(port<=0 || port > (1<<16)-1 ){
     puts("Invalid port.");
   return 1;
 }
 /*Setting Up Server Address struct*/
  memset(&servaddr,0,sizeof servaddr);
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr = nIP;
  servaddr.sin_port = htons(port);

  if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof servaddr)<0){
    puts("Connection Failed.");
    return 1;
  }

  char op[MAX_SIZE+1];
  char res[MAX_SIZE+1];
  int n;
  puts("Connected");
  /*Sending Requests and printing results*/
  while(fgets(op,MAX_SIZE,file)!=NULL){
    write(sockfd,op,strlen(op));
    n=read(sockfd,res,MAX_SIZE);
    if(n<=0)break;
    res[n-1]=0;
    puts(res);
    usleep(wait);
  }
  fclose(file);
 close(sockfd);

}
